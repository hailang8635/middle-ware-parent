package com.quart.job.task;

public interface TaskService {
    void run(String params);
}
