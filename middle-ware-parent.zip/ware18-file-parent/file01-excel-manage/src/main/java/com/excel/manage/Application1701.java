package com.excel.manage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application1701 {
    public static void main(String[] args) {
        SpringApplication.run(Application1701.class,args) ;
    }
}
