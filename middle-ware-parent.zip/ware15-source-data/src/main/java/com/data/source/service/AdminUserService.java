package com.data.source.service;

import com.data.source.entity.AdminUser;

public interface AdminUserService {

    AdminUser selectByPrimaryKey(Integer id) ;

}
