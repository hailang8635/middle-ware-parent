package com.boot.common;

public interface VersionService {
    String getVersion () ;
}
